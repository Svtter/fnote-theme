# leanote的fexo主题


本主题根据[hexo-fexo]()主题进行移植，感谢forsigner。

